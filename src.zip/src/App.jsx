import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [pincode, setPincode] = useState('');
  const [postData, setPostData] = useState([]);
  const [filterText, setFilterText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLookup = async () => {
    if (pincode.length !== 6) {
      setError('Please enter a valid 6-digit pincode');
      return;
    }

    setLoading(true);
    setError('');
    setPostData([]);

    try {
      const response = await axios.get(`https://api.postalpincode.in/pincode/${pincode}`);
      const data = response.data[0];

      if (data.Status === 'Error') {
        setError('Invalid Pincode');
      } else {
        setPostData(data.PostOffice || []);
      }
    } catch (err) {
      setError('Failed to fetch data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const filteredData = postData.filter((post) =>
    post.Name.toLowerCase().includes(filterText.toLowerCase())
  );

  return (
    <div className="app">
      <h1>Pincode Lookup</h1>
      <div className="form-group">
        <input
          type="text"
          placeholder="Enter 6-digit Pincode"
          value={pincode}
          onChange={(e) => setPincode(e.target.value)}
        />
        <button onClick={handleLookup}>Lookup</button>
      </div>
      {error && <div className="error">{error}</div>}
      {loading && <div className="loader">Loading...</div>}
      <div className="filter-group">
        <input
          type="text"
          placeholder="Filter by post office name"
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
        />
      </div>
      <div className="post-data">
        {filteredData.length > 0 ? (
          filteredData.map((post, index) => (
            <div className="post-item" key={index}>
              <h2>{post.Name}</h2>
              <p>Pincode: {post.Pincode}</p>
              <p>District: {post.District}</p>
              <p>State: {post.State}</p>
            </div>
          ))
        ) : (
          !loading && <p>Couldn’t find the postal data you’re looking for…</p>
        )}
      </div>
    </div>
  );
}

export default App;
